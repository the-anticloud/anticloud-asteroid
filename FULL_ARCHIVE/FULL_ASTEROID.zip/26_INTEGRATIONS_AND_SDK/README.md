# 26 Integrations And Sdk

**Project:** ASTEROID
**Upstream:** https://github.com/asteroid-team/asteroid

Content specific to ASTEROID in category AUDIO_CONSUMER.
