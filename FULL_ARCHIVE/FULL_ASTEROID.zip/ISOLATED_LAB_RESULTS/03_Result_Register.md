# Result Register

**Project:** ASTEROID

| Result | Pass Condition | Command | Observed | Status |
| --- | --- | --- | --- | --- |
| (none yet) | (define before running) | (verbatim) | (unrecorded) | NOT RUN |
