# 14 Developer Cookbooks

**Project:** ASTEROID
**Upstream:** https://github.com/asteroid-team/asteroid

Content specific to ASTEROID in category AUDIO_CONSUMER.
